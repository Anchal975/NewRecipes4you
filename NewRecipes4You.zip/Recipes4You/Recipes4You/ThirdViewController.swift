//
//  ThirdViewController.swift
//  Recipes4You
//
//  Created by mac air 2017 256 on 2020-12-03.
//

import UIKit

class ThirdViewController: UIViewController {

    @IBOutlet weak var Recipe: UITextView!
    @IBOutlet weak var MainTitle: UITextField!
    @IBOutlet weak var BigImg: UIImageView!
    var recipe=""
    var maintitle = ""
    var bigimg = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        MainTitle.text=title
        Recipe.text=recipe
        BigImg.image=UIImage(named: bigimg)
        

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
