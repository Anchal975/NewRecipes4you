//
//  SecondViewController.swift
//  Recipes4You
//
//  Created by mac air 2017 256 on 2020-12-03.
//

import UIKit

class SecondViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource,UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        tempList2.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let dishObject = tempList2[indexPath.row]
        let cell = dishTable.dequeueReusableCell(withIdentifier: "dishes") as? DishCell
        cell?.dishCellSetup(dish: dishObject)
        return cell!
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        name = tempList2[indexPath.row].DishName
        image = tempList2[indexPath.row].Image
        recip=tempList2[indexPath.row].Recipe
        performSegue(withIdentifier: "showDetails", sender: self)
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return subtypes.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return subtypes[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        tempList2.removeAll()
        //calling this funtion is filling the temp array
        findRecipes(type: subtypes[row])
        dishTable.reloadData()
    }

    @IBOutlet weak var dishTable: UITableView!
    @IBOutlet weak var coursePicker: UIPickerView!
    var recipeList2=[Dish]() // this is blank
    var tempList2=[Dish]()
    let subtypes = ["Starters","Main Course","Deserts"]
    var name=""
    var image=""
    var recip=""
    
    
    func findRecipes(type:String){
        for recipe in recipeList2{
            if type == recipe.SubCategory{
                tempList2.append(recipe)
            }
        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let tvc = segue.destination as? ThirdViewController
        tvc?.maintitle=name
        tvc?.bigimg=image
        tvc?.recipe=recip
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        coursePicker.delegate=self
        coursePicker.dataSource=self
        dishTable.dataSource=self
        dishTable.delegate=self
        
        tempList2.removeAll()
        findRecipes(type: subtypes[0])
        dishTable.reloadData()
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
