//
//  Dish.swift
//  Recipes4You
//
//  Created by mac air 2017 256 on 2020-11-29.
//

import Foundation
class Dish{
    var Category:String
    var SubCategory:String
    var DishName:String
    var Recipe:String
    var Image:String
    init(cate:String,sub:String,name:String,recipe:String,img:String) {
        self.Category=cate
        self.SubCategory=sub
        self.DishName=name
        self.Recipe=recipe
        self.Image=img
    }
}
